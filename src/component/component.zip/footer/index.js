import React from "react";

function Footer() {

    return (
        <footer className="footer">
        <div className="container-fluid">          
          <div className="copyright ml-auto">
           COPYRIGHT &copy; 2022 RXLifeScience,All right Reserved
          </div>
        </div>
      </footer>
    )
}

export default Footer;